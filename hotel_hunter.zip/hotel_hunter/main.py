"""
Hotel Hunter — Main Orchestrator
==================================
Coordinates all agents in parallel:

  1. Query Parser Agent        — decompose user query
  2. Crawler Agents (parallel) — TripAdvisor, Google, Booking simultaneously
  3. Per-hotel analysis (parallel):
       a. Text Analyst Agent   — scan reviews
       b. Vision Analyst Agent — scan images
  4. Scorer Agent              — combine scores, generate summary
  5. Report                    — ranked output with evidence

Usage:
    python main.py --query "dark purple couch" --city "New York"
    python main.py --query "rooftop pool with mountain views" --city "Denver"
"""

import asyncio
import argparse
import json
from pathlib import Path
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
import aiosqlite

from db.database import init_db, upsert_hotel, insert_review, insert_image, save_analysis, DB_PATH
from agents.query_parser import parse_query
from agents.text_analyst import analyze_reviews
from agents.vision_analyst import analyze_images
from agents.scorer import score_and_summarize
from crawlers.tripadvisor import TripAdvisorCrawler
from crawlers.google_hotels import GoogleHotelsCrawler
from crawlers.booking import BookingCrawler

console = Console()


# ─── Step 1: Crawl all sources in parallel ───────────────────────────────────

async def crawl_all_sources(city: str, db) -> list[dict]:
    """Run all crawlers concurrently and merge results."""
    console.print(f"\n[bold]Step 1: Crawling all sources for [cyan]{city}[/]...[/]")

    crawlers = [
        TripAdvisorCrawler(),
        GoogleHotelsCrawler(),
        BookingCrawler(),
    ]

    tasks = [crawler.crawl_city(city, db) for crawler in crawlers]
    raw_results = await asyncio.gather(*tasks, return_exceptions=True)

    # Close crawlers
    for c in crawlers:
        await c.close()

    # Flatten and deduplicate by hotel name (case-insensitive)
    all_hotels: dict[str, dict] = {}

    for source_results in raw_results:
        if isinstance(source_results, Exception):
            console.print(f"[red]Crawler error: {source_results}[/]")
            continue
        for hotel in source_results:
            key = hotel["name"].lower().strip()
            if key not in all_hotels:
                all_hotels[key] = {**hotel, "reviews": list(hotel.get("reviews", [])),
                                   "images": list(hotel.get("images", []))}
            else:
                # Merge reviews and images from multiple sources
                all_hotels[key]["reviews"].extend(hotel.get("reviews", []))
                all_hotels[key]["images"].extend(hotel.get("images", []))

    merged = list(all_hotels.values())
    console.print(f"[green]✓ Total unique hotels found:[/] {len(merged)}")
    return merged


# ─── Step 2: Persist to DB ───────────────────────────────────────────────────

async def persist_hotels(hotels: list[dict], db) -> dict[str, int]:
    """Save hotels, reviews, and images to DB. Returns name→hotel_id mapping."""
    name_to_id = {}
    for hotel in hotels:
        hotel_id = await upsert_hotel(
            db,
            name=hotel["name"],
            city=hotel["city"],
            source=hotel["source"],
            source_url=hotel["source_url"],
            address=hotel.get("address"),
            rating=hotel.get("rating"),
        )
        name_to_id[hotel["name"]] = hotel_id

        for review in hotel.get("reviews", []):
            await insert_review(
                db, hotel_id,
                source=review.get("source", "unknown"),
                text=review["text"],
                author=review.get("author"),
                rating=review.get("rating"),
                review_url=review.get("review_url"),
            )

        for image in hotel.get("images", []):
            await insert_image(
                db, hotel_id,
                url=image["url"],
                source=image.get("source", "unknown"),
                caption=image.get("caption"),
                image_type=image.get("image_type", "official"),
            )

    return name_to_id


# ─── Step 3: Analyze each hotel in parallel ──────────────────────────────────

async def analyze_hotel(hotel: dict, parsed_query: dict, raw_query: str) -> dict:
    """
    Run text + vision analysis in parallel for a single hotel.
    Returns a scored result dict.
    """
    hotel_name = hotel["name"]

    # Text and vision run concurrently per hotel
    text_task = analyze_reviews(hotel_name, hotel.get("reviews", []), parsed_query)
    vision_task = analyze_images(hotel_name, hotel.get("images", []), parsed_query)

    text_result, vision_result = await asyncio.gather(text_task, vision_task)

    result = await score_and_summarize(
        hotel_name=hotel_name,
        hotel_url=hotel.get("source_url", ""),
        hotel_rating=hotel.get("rating"),
        query=raw_query,
        text_result=text_result,
        vision_result=vision_result,
    )

    return result


async def analyze_all_hotels_parallel(hotels: list[dict], parsed_query: dict,
                                       raw_query: str) -> list[dict]:
    """
    Analyze all hotels concurrently — each hotel gets its own text+vision agents.
    Semaphore limits to 5 parallel analyses to avoid API rate limits.
    """
    console.print(f"\n[bold]Step 3: Running parallel analysis on {len(hotels)} hotels...[/]")

    sem = asyncio.Semaphore(5)

    async def bounded_analyze(hotel):
        async with sem:
            return await analyze_hotel(hotel, parsed_query, raw_query)

    tasks = [bounded_analyze(hotel) for hotel in hotels]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    clean = []
    for r in results:
        if isinstance(r, Exception):
            console.print(f"[red]Analysis error: {r}[/]")
        else:
            clean.append(r)

    return sorted(clean, key=lambda x: x["final_score"], reverse=True)


# ─── Step 4: Save results + print report ─────────────────────────────────────

async def save_results(results: list[dict], name_to_id: dict, raw_query: str, db):
    for r in results:
        hotel_id = name_to_id.get(r["hotel_name"])
        if hotel_id:
            await save_analysis(
                db, hotel_id, raw_query,
                r["text_score"], r["vision_score"], r["final_score"],
                r["evidence_text"], r["evidence_images"], r["summary"]
            )


def print_report(results: list[dict], raw_query: str, city: str):
    console.print()
    console.print(Panel(
        f"[bold]Hotel Hunter Results[/]\n"
        f"Query: [italic cyan]{raw_query}[/]\n"
        f"City: [italic]{city}[/]",
        box=box.DOUBLE_EDGE,
        style="bold"
    ))

    top = [r for r in results if r["final_score"] > 0.1][:5]

    if not top:
        console.print("[yellow]No hotels found with a match score above 10%.[/]")
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan", expand=True)
    table.add_column("Rank", width=4)
    table.add_column("Hotel", min_width=24)
    table.add_column("Match", width=7)
    table.add_column("Text", width=6)
    table.add_column("Vision", width=7)
    table.add_column("Rating", width=7)

    for i, r in enumerate(top, 1):
        score_color = "green" if r["final_score"] > 0.6 else "yellow" if r["final_score"] > 0.3 else "red"
        table.add_row(
            str(i),
            r["hotel_name"],
            f"[{score_color}]{r['final_score']*100:.0f}%[/]",
            f"{r['text_score']*100:.0f}%",
            f"{r['vision_score']*100:.0f}%",
            f"{r['hotel_rating']:.1f}" if r.get("hotel_rating") else "—",
        )

    console.print(table)

    console.print("\n[bold]Top Match Details:[/]\n")
    for i, r in enumerate(top[:3], 1):
        console.print(f"[bold cyan]#{i} {r['hotel_name']}[/]")
        console.print(f"   {r['summary']}")
        if r["evidence_text"]:
            console.print(f"   [dim]Review evidence:[/] {r['evidence_text'][0][:120]}...")
        if r["evidence_images"]:
            console.print(f"   [dim]Photo evidence:[/] {r['evidence_images'][0]['description']}")
            console.print(f"   [dim]Image URL:[/] {r['evidence_images'][0]['url']}")
        console.print(f"   [dim]Source:[/] {r['hotel_url']}")
        console.print()

    # Save JSON report
    report_path = Path(__file__).parent / "output" / f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    report_path.parent.mkdir(exist_ok=True)
    with open(report_path, "w") as f:
        json.dump({
            "query": raw_query,
            "city": city,
            "timestamp": datetime.now().isoformat(),
            "results": results,
        }, f, indent=2)
    console.print(f"[dim]Full results saved to: {report_path}[/]")


# ─── Main entry point ────────────────────────────────────────────────────────

async def run(raw_query: str, city: str):
    console.print(Panel(
        f"[bold cyan]🏨 Hotel Hunter[/]\n"
        f"Finding: [italic]{raw_query}[/]\n"
        f"City: [italic]{city}[/]",
        box=box.ROUNDED
    ))

    # Init DB
    await init_db()

    async with aiosqlite.connect(DB_PATH) as db:
        # Step 1: Parse query
        console.print(f"\n[bold]Step 0: Parsing query...[/]")
        parsed_query = await parse_query(raw_query)
        console.print(f"  Keywords: {parsed_query['text_keywords']}")
        console.print(f"  Visual:   {parsed_query['visual_features']}")
        console.print(f"  Context:  {parsed_query['context']}")

        # Step 2: Crawl all sources in parallel
        hotels = await crawl_all_sources(city, db)

        # Step 3: Persist to DB
        console.print(f"\n[bold]Step 2: Persisting {len(hotels)} hotels to database...[/]")
        name_to_id = await persist_hotels(hotels, db)

        # Step 4: Parallel analysis (text + vision per hotel, hotels in parallel)
        results = await analyze_all_hotels_parallel(hotels, parsed_query, raw_query)

        # Step 5: Save analysis results
        await save_results(results, name_to_id, raw_query, db)

    # Step 6: Print report
    print_report(results, raw_query, city)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Hotel Hunter — Find specific features in hotels")
    parser.add_argument("--query", "-q", required=True,
                        help='Feature to search for, e.g. "dark purple couch"')
    parser.add_argument("--city", "-c", required=True,
                        help='City to search in, e.g. "New York"')
    args = parser.parse_args()

    asyncio.run(run(args.query, args.city))
